const http = require('http');
const fs = require('fs');
const url = require("url");
const flash = require('connect-flash');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const json = require('json');
const request = require('request');
const session = require('express-session');
const { userInfo } = require('os');
process.env.TZ = "Asia/Calcutta";
var date = new Date().toString();
const express = require("express"),
    app = express()
bodyparser = require("body-parser"),
    path = require("path");
app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
app.use(flash());  
app.use((req, res, next) => {
    res.locals.messages = req.flash();
    next();
  });
  
app.use(express.static(path.join(__dirname, "public")))
app.use(bodyParser.json());
app.set("view engine", "ejs")
app.use(bodyparser.urlencoded({ extended: true }))
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "pinkshakti",
    port: "3306"
})
db.connect((err) => {
    if (err) {
        console.log(err);
        throw err;
    }
    else {
        console.log("we are connect to mysqli database");
    }
})
app.get("/", (req, res) => {
    res.render("login.ejs");
});
app.get("/dashboard", (req, res) => {
    if (req.session.username) {
        var usertype = req.session.user_type;
        var area = req.session.area;
        // console.log(usertype);
    if((usertype)==1)
    {
        var getcount = `Select (select count(*) from users ) as Count1, (select count(*) from Crime WHERE crime_type='1' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}')) as Count2 ,(select count(*) from Crime WHERE crime_type='2' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}')) as Count3,(select count(*) from Crime WHERE crime_type='3' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}')) as Count4 `;
        db.query(getcount, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("index.ejs", { count: data, permission,username });
            }
        })
    }
    if((usertype)==2)
    {
        var getcount = `Select (select count(*) from users ) as Count1, (select count(*) from Crime WHERE crime_type='1' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}')) as Count2 ,(select count(*) from Crime WHERE crime_type='2' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}')) as Count3,(select count(*) from Crime WHERE crime_type='3' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}')) as Count4 `;
        db.query(getcount, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("index.ejs", { count: data, permission,username });
            }
        })

    }
    if((usertype)==3)
    {
        // console.log("test get data district");
        var getcount = `Select (select count(*) from users ) as Count1, (select count(*) from Crime WHERE crime_type='1' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}')) as Count2 ,(select count(*) from Crime WHERE crime_type='2' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}')) as Count3,(select count(*) from Crime WHERE crime_type='3' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}')) as Count4 `;
        db.query(getcount, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("index.ejs", { count: data, permission,username });
            }
        })
    }
    }
    else {
        console.log("Please Login");
        res.redirect("/");
    }

})
app.get("/user", function (req, res, next) {
    if (req.session.username) {

        var query = "SELECT * FROM users ORDER BY id desc";
        db.query(query, function (err, data) {
            if (err) {
                req.flash('error', err)
            }
            else {
                var permission = req.session.permision;
                var username = req.session.username;
                res.render('user.ejs', { sampledata: data, permission ,username})
            }
        })
    }
    else {
        console.log("Please Login");
        res.redirect("/");
    }
});
app.get("/userdelete/:id", function (req, res, next) {
    var id = req.params.id;
    var del = `DELETE FROM user WHERE id="${id}"`;
    db.query(del, function (err, data) {
        if (err) {
            throw (err);
        }
        else {
            console.log("User delete Successfully");
            res.redirect("/user");
        }
    });
});
app.get("/updateusers/:id", function (req, res, next) {
    var id = req.params.id
    var rest = `SELECT * FROM user WHERE id="${id}"`;
    db.query(rest, function (err, data) {
        if (err) {
            throw (err);
        }
        else {
            console.log({ Updatedata: data });
            res.render('updateuser.ejs', ({ updatedata: data }));
        }
    })
});
app.get("/useradd", function (req, res, next) {
    res.render("adduser.ejs");
});
app.post("/useradd", function (req, res, next) {
    var uname = req.body.name;
    var email = req.body.email;
    var phone = req.body.phone;
    var qualification = req.body.qualification;
    var dob = req.body.date;
    var gender = req.body.gender;
    var address = req.body.address;
    var insertdata = `INSERT INTO users VALUES (NULL,'${uname}','${email}','${phone}','${qualification}','${dob}','${gender}','${address}')`;
    db.query(insertdata, function (err, data) {
        if (err) {
            throw (err);
        }
        else {
            console.log("user Add successfully");
            res.redirect("/user");
        }
    });
});
app.get("/manuallycrime",function(req,res, next){
    if(req.session.username){
        var usertype = req.session.user_type;
        var area = req.session.area;
        if((usertype) == 1){
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='1' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}')`;
           db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("manuallycrime.ejs",{permission,sampledata:data,username});
            }
         });


         }
       if((usertype) == 2){
            // console.log("state");
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='1' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}')`;
           db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("manuallycrime.ejs",{permission,sampledata:data,username});
            }
         });


         }
       if((usertype) == 3){
            // console.log("state");
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='1' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}')`;
           db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("manuallycrime.ejs",{permission,sampledata:data,username});
            }
         });


    }
    }
    else {
        console.log("Plase login");
        res.redirect("/");
    }
})
app.get("/mapcrime", function (req, res, next) {
    if (req.session.username) 
    {
        var usertype = req.session.user_type;
        var area = req.session.area;
        if((usertype) == 1)
        {
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='2' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}')`;
        db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("mapcrime.ejs",{permission,sampledata:data,username});
            }
         });
         }
       if((usertype) == 2)
       {
            // console.log("state");
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='2' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}')`;
        // console.log(queryss);
           db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("mapcrime.ejs",{permission,sampledata:data,username});
            }
         });


         }
       if((usertype) == 3){
            // console.log("state");
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='2' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}')`;
           db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("mapcrime.ejs",{permission,sampledata:data,username});
            }
         });


       }
    }
    else {
        console.log("Plase login");
        res.redirect("/");
    }

})
app.get("/emergencyshakes", function (req, res, next) {
    if (req.session.username)
     {
       var usertype = req.session.user_type;
        var area = req.session.area;

        if((usertype) == 1)
        {
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='3' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}')`;  
        db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("emergencyshake.ejs",{permission,sampledata:data,username});
            }
         });
         }
        if((usertype) == 2)
       {
            // console.log("state");
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='3' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}')`;
        // console.log(queryss);
           db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("emergencyshake.ejs",{permission,sampledata:data,username});
            }
         });


         }
        if((usertype) == 3){
            // console.log("state");
        var queryss = `SELECT Crime.*,users.name FROM Crime,users WHERE users.id=crime.user_id && crime.crime_type='3' && crime.pin_code IN(SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}')`;
           db.query(queryss, function(err, data){
            if(err){
                throw(err);
            }  
            else
            {     
               var permission = req.session.permision;
               var username = req.session.username;
                res.render("emergencyshake.ejs",{permission,sampledata:data,username});
            }
         });


         }

    }
    else {
        console.log("Please login");
        res.render("/");
    }
})
app.get("/zipcode", function (re, res, next) {
    if (req.session.username) {
        var getzip = "SELECT * FROM zipcode";
        db.query(getzip, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                console.log({ zipcods: data });
                res.render("zipcodes", { zipcodes: data });
            }
        })
    }
    else {
        res.redirect("/");
    }
    // res.render("zipcodes.ejs");
})
app.get("/addzipcode", function (req, res, next) {
    if (req.session.username) {
        res.render("addzipcode");
    }
    else {
        res.redirect("/");
    }
})
app.post("/zipcodeadd", function (req, res, next) {
    if (req.session.username) {
        var dist = req.body.district;
        var zip = req.body.zipcode;
        var district = `INSERT INTO zipcode VALUES(NULL,'${dist}','${zip}','1')`;
        db.query(district, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                console.log("Zipcode Add successfully");
                res.redirect("/zipcode");
            }
        })
    }
    else {
        res.redirect("/");
    }
})
app.get("/deletezpcode/:id", function (req, res, next) {
    var zid = req.params.id;
    var deletezip = `DELETE FROM zipcodes WHERE id='${zid}'`;
    db.query(deletezip, function (err, data) {
        if (err) {
            throw (err)
        }
        else {
            console.log("Delete zipcode successfully");
            res.redirect("/zipcode");
        }
    })
})
app.post("/auth", function (request, response, next) {
    var email = request.body.email;
    // console.log(email);
    var password = request.body.password;
    // console.log(password);
    if (email && password) {
        db.query('SELECT `admin`.* ,`role`.`permision` FROM `admin`,`role` WHERE admin.role=role.id AND admin.email = ? AND admin.password = ? AND admin.status= ?', [email, password, '1'], function (error, results, fields) {
            // If there is an issue with the query, output the error
            if (error) throw error;
            // If the account exists
            if (results.length > 0) {
                results.forEach(function (datas) {
                    // datas.role;

                    request.session.loggedin = true;
                    var userid = request.session.id = datas.id;
                    var username = request.session.username = datas.name;
                    var role = request.session.role = datas.role;
                    var usertype = request.session.user_type = datas.user_type;
                    var district = request.session.dist = datas.dist;
                    var area = request.session.area = datas.area_access;
                    var ppp = datas.permision;
                    // console.log(usertype);
                    if (usertype == 1) {
                        db.query(`SELECT * FROM districtdata WHERE state='${area}'`, function (error, results, fields) {
                            if (results.length > 0) {
                                results.forEach(function (datas) {
                                    request.session.loggedin = true;
                                    var pincodes = request.session.pincode = datas.zipcode;
                                    // console.log(pincodes);

                                });
                            };

                        });

                    }
                    if (usertype == 2) {
                        db.query(`SELECT * FROM districtdata WHERE zone='${area}'`, function (error, results, fields) {
                            if (results.length > 0) {
                                results.forEach(function (datas) {
                                    request.session.loggedin = true;
                                    var pincodes = request.session.pincode = datas.zipcode;
                                    // console.log(pincodes);

                                });
                            };

                        });

                    }
                    if (usertype == 3) {
                        db.query(`SELECT * FROM districtdata WHERE dist='${area}'`, function (error, results, fields) {
                            if (results.length > 0) {
                                results.forEach(function (datas) {
                                    request.session.loggedin = true;
                                    var pincodes = request.session.pincode = datas.zipcode;
                                    // console.log(pincodes);

                                });
                            };

                        });

                    }



                    var arraper = String(ppp).split(',').map(Number);
                    var permission = request.session.permision = arraper;
                    // console.log(userid);




                });
                // console.log({ datas: results });
                request.flash('success', 'Welcome To admin Panel Login Successfully');
                response.redirect('/dashboard');
            } else {
                request.flash('success', 'Please Enter valid Email Or Password');
                response.redirect("/");
            }
            response.end();
        });

    }
    else {
        request.flash('success', 'Email Or password Is Required');
        response.redirect("/");

    }
});
app.get('/logout', function (req, res) {
    console.log("logging out!");

    req.session.destroy();
    res.redirect('/');
});
app.post('/updateremark', function (req, res, next) {
    if (req.session.username) {
        var id = req.body.id;
        var remark = req.body.remark;
        var sql = `UPDATE Crime SET remark = '${remark}' WHERE id = '${id}'`;
        db.query(sql, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                req.flash('success','Remark Add Successfully');
                res.redirect("/manuallycrime");
            }
        });
    }
    else {
        res.redirect("/");
    }
})
app.post('/updatemapremark', function (req, res, next) {
    if (req.session.username) {
        var id = req.body.id;
        var remark = req.body.remark;
        var sql = `UPDATE Crime SET remark = '${remark}' WHERE id = '${id}'`;
        db.query(sql, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                req.flash('success','Remark Add Successfully')
                res.redirect("/mapcrime");
            }
        });
    }
    else {
        res.redirect("/");
    }
})
app.get('/updatemancrime/:id/:status', function (req, res, next) {
    if (req.session.username) {
        var id = req.params.id;
        var status = req.params.status;
        var update = `UPDATE Crime SET status='${status}' WHERE id='${id}'`;
        db.query(update, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
               req.flash('success','Crime Report status Update Successfully')
                
                res.redirect("/manuallycrime");
            }
        })
    }
    else {
        res.redirect("/");
    }

});
app.get('/updateemercrime/:id/:status', function (req, res, next) {
    if (req.session.username) {
        var id = req.params.id;
        var status = req.params.status;
        var update = `UPDATE Crime SET status='${status}' WHERE id='${id}'`;
        db.query(update, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
               
                req.flash('success','status change successfully');
                res.redirect("/emergencyshakes");
            }
        })
    }
    else {
        res.redirect("/");
    }

});
app.post('/updateemerremark', function (req, res, next) {
    if (req.session.username) {
        var id = req.body.id;
        var remark = req.body.remark;
        var sql = `UPDATE Crime SET remark = '${remark}' WHERE id = '${id}'`;
        db.query(sql, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                req.flash('success','Remark Add successfully');
                res.redirect("/emergencyshakes");
            }
        });
    }
    else {
        res.redirect("/");
    }
})
app.get('/updatemapcrime/:id/:status', function (req, res, next) {
    if (req.session.username) {
        var id = req.params.id;
        var status = req.params.status;
        var update = `UPDATE Crime SET status='${status}' WHERE id='${id}'`;
        db.query(update, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                
                req.flash('success','Report Status Successfully');
                res.redirect("/mapcrime");
            }
        })
    }
    else {
        res.redirect("/");
    }

});
app.get("/termscondition", function (req, res, next) {
    if (req.session.username) {
        var querys = "SELECT * FROM term_condition";
        db.query(querys, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("termscondtion.ejs", { permission, policy: data ,username});
            }
        })
    }
    else {
        res.redirect("/");
    }

})
app.get("/privacy_policy", function (req, res, next) {
    if (req.session.username) {
        var querys = "SELECT * FROM term_condition";
        db.query(querys, function (err, data) {
            if (err) {
                throw (err)
            }
            else {
                // console.log({policy:data})
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("privacypolicy", { permission, policy: data ,username});
            }
        })
    }
    else {
        res.redirect("/");
    }

})
app.post('/updatepolicy', function (req, res, next) {
    var policy = req.body.ram;
    console.log(policy);
    console.log("update policy");
})
app.post('/termsupdate', function (req, res, next) {
    if (req.session.username) {
        var terms = req.body.terms;
        // console.log(`UPDATE term_condition SET term_condition = '${terms}' WHERE id = '1'`);
        var updateterms = `UPDATE term_condition SET term_condition = '${terms}' WHERE id = '1'`;
        db.query(updateterms, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
               req.flash('success','Terms & Condition Update Successfully');
                res.redirect("/termscondition");
            }
        })
    }
    else {
        res.redirect("/");
    }
})
app.post('/pupdate', function (req, res, next) {
    if (req.session.username) {

        var pol = req.body.pol;
        // console.log(`UPDATE term_condition SET term_condition = '${terms}' WHERE id = '1'`);
        var updateterms = `UPDATE term_condition SET privacypolicy = '${pol}' WHERE id = 1`;
        db.query(updateterms, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
               req.flash('success','Privacy Policy Update Successfully');
                res.redirect("/privacy_policy");
            }
        })
    }
    else {
        res.redirect("/");
    }
})
app.get('/systemuser', function (req, res, next) {
    if (req.session.username) {
        var getuser = `SELECT admin.* ,role.role as roles FROM admin,role WHERE role.id=admin.role`;
        db.query(getuser, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("systemuser.ejs", { permission, userdata: data ,username});
            }
        })

    }

    else {

        res.redirect("/");
    }
})
app.get("/addsystemusers", function (req, res, next) {
    if (req.session.username) {

        var getrole = `SELECT DISTINCT(zone) FROM districtdata`;
        db.query(getrole, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                var getdata = `SELECT * FROM role`;
                db.query(getdata,function(err, datass){
                    if (err) {
                        throw (err);
                        }
                    else {
                        var query = `SELECT DISTINCT dist FROM districtdata`;
                        db.query(query,function(err,dist){
                         if (err) {
                        throw (err);
                          }
                          else
                          {
                          var query = `SELECT DISTINCT state FROM districtdata`;
                          db.query(query,function(err,state){
                           if (err) {
                              throw (err);
                            }
                            else
                            {
                             var permission = req.session.permision;
                             var username = req.session.username;
                             res.render("addsystemusers.ejs", { permission, distdata: data, roldata: datass ,zila:dist,state:state,username});
                            }
                        })
                       }
                    });
                }
                })
            }
        })

    }
    else {
        res.redirect("/");
    }
})
app.post("/systemuseradd", function (req, res, next) {
    // var userid=req.session.id;
    var username = req.body.username;
    var email = req.body.email;
    var phone = req.body.phone;
    var password = req.body.password;
    var role = req.body.role;
    var user_type = req.body.user_type;
    var getdat = `SELECT *  FROM admin WHERE  email='${email}'`;
    db.query(getdat, function (error, results) {
        if (results.length > 0) {
            console.log("This email id Is regitered");
            res.redirect("/addsystemusers");
        }
        else {
            if (user_type == 1) {
                var area = req.body.state;
            }
            if (user_type == 2) {
                var area = req.body.zone;
            }
            if (user_type == 3) {
                var area = req.body.district;
            }


            var insertdata = `INSERT INTO admin VALUES (null,'${username}','${phone}','${email}','${password}',null,null,'1','${role}',null,'${user_type}','${area}',null)`;
            db.query(insertdata, function (err, data) {
                if (err) {
                    throw (err);
                }
                else {
                    req.flash('success', 'Admin User Add successfully');
                    res.redirect("/systemuser");
                }
            })
        }

    });

})
app.get("/updateuser/:id/:status", function (req, res, next) {
    if (req.session.username) {
        var id = req.params.id;
        var status = req.params.status;
        var updateuser = `UPDATE users SET status='${status}' WHERE id='${id}' `;
        db.query(updateuser, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                req.flash('success', 'User status Update successfully');
                res.redirect("/user");
            }
        })
    }
    else {
        res.redirect("/");
    }

})
app.get("/usercontact/:id", function (req, res, next) {
    if (req.session.username) {
        var id = req.params.id;
        var gets = `SELECT user_contact.*,users.name as username FROM user_contact,users WHERE users.id=user_contact.user_id && user_contact.user_id='${id}'`;
        db.query(gets, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                console.log("user contact");
                var permission = req.session.permision;
                res.render("contact.ejs", { permission, contact: data });
            }
        })
    }
    else {
        res.redirect("/");
    }
})
app.get("/role", function (req, res, next) {
    if (req.session.username) {
        var get = `SELECT * FROM role`;
        db.query(get, function (err, data) {
            if (err) {
                throw (err);
            }
            else {

                var permission = req.session.permision;
                var username = req.session.username;
                res.render("rolemanage.ejs", { permission, roledata: data ,username});
                

            }
        })
    }
    else {
        res.redirect("/");
    }

})
app.get("/addrole", function (req, res, next) {
    if (req.session.username) {
        var get = `SELECT * FROM permission`;
        db.query(get, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                console.log({ permissions: data });
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("addrole.ejs", { permission, permissions: data ,username});
            }
        })
    }
    else {
        res.redirect("/");
    }

})
app.post("/roleadd", function (req, res, next) {
    if (req.session.username) {
        var rolename = req.body.role;
        var permissions = req.body.permission;
        //var fper=json_encode(permissions);


        var arole = `INSERT INTO role VALUES (null,'${rolename}','${permissions}','1')`;
        db.query(arole, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                console.log("Role add sucessfully");
                res.redirect("/role");
            }
        })
    } else {
        res.redirect("/");
    }
    // console.log(permission);

})
app.get("/updaterole/:id/:status", function (req, res, next) {
    if (req.session.username) {
        var id = req.params.id;
        var status = req.params.status;
        var updaterole = `UPDATE role SET status='${status}' WHERE id='${id}'`;
        db.query(updaterole, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                res.redirect("/role");

            }
        })
    }
    else {
        res.redirect("/");
    }
})
app.get("/suseraction/:id/:status", function (req, res, next) {
    var id = req.params.id;
    var status = req.params.status;
    var updateuser = `UPDATE admin SET status='${status}' WHERE id='${id}'`;
    db.query(updateuser, function (err, data) {
        if (err) {
            throw (err)
        }
        else {
            req.flash('success', 'Admin User status Update successfully');
            res.redirect("/systemuser");
        }
    })
})
app.get("/analytics", function(req, res,next){
    if (req.session.username) {
        var usertype = req.session.user_type;
        var area = req.session.area;
        if ((usertype) == 1)
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                    {
                        if(err)
                        {
                            throw(err);
                        }
                        else 
                        {
                           var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                           db.query(query,function(err,district)
                           {

                           if(err)
                           {
                            throw(err);
                           }
                           else{
                            var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                            db.query(query,function(err,pincode)
                            {
 
                            if(err)
                            {
                             throw(err);
                            }
                            else{
//  
                                // console.log({zila:district});
                                // console.log({pin:pincode});
                                var usertype = req.session.user_type;
                                var permission = req.session.permision;
                                var username = req.session.username;
                                res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype,username });
                           }
                         });
                        }
                            })
                       
                        }
            })
        }
        if ((usertype) == 2)
         {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                    {
                        if(err)
                        {
                            throw(err);
                        }
                        else 
                        {
                           var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                           db.query(query,function(err,district)
                           {

                           if(err)
                           {
                            throw(err);
                           }
                           else{
                            var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                           
                            db.query(query,function(err,pincode)
                            {
 
                            if(err)
                            {
                             throw(err);
                            }
                            else{
                var permission = req.session.permision;
                var username = req.session.username;

                res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype,username });
               }
                         });
                        }
                            })
                       
                        }
            })


        }
        if ((usertype) == 3)
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                    {
                        if(err)
                        {
                            throw(err);
                        }
                        else 
                        {
                          
                            var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                            db.query(query,function(err,pincode)
                            {
 
                            if(err)
                            {
                             throw(err);
                            }
                            else{

                            
                               var usertype = req.session.user_type;
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("analytics.ejs",{permission, alldata: data,pin:pincode, usertype,username });
               }
                         });
                       
                       
                        }
            })

        }
    }
    else {
        res.redirect("/");
    }


})
app.post("/filteranalytics",function(req,res,next){
    if (req.session.username) {
    var usertype = req.session.user_type;
    var area = req.session.area;
    var dist=req.body.dist;
    var pincode=req.body.pincode;
    var age=req.body.age;
    var type=req.body.type;
   
    if ((usertype) == 1)
    {
        if((dist)!='' && (pincode)=='' && (age)=='' && (type)=='')
        {

        var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })
        }
        else if((dist)=='' && (pincode)!='' && (age)=='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code ='${pincode}') AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)=='' && (pincode)=='' && (age)!='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=crime.user_id  ) AS ddata ,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=crime.user_id ) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=crime.user_id ) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=crime.user_id ) AS isdata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=crime.user_id ) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=crime.user_id ) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=crime.user_id ) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=crime.user_id ) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=crime.user_id ) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=crime.user_id ) AS emerdata FROM dual`;
        //    console.log(getdata);
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })
        }
        else if((dist)=='' && (pincode)=='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence'  && crime_type='${type}' ) AS ddata ,(SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments'  && crime_type='${type}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing'  && crime_type='${type}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring'  && crime_type='${type}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures'  && crime_type='${type}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch'  && crime_type='${type}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment'  && crime_type='${type}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content'  && crime_type='${type}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road'  && crime_type='${type}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS'  && crime_type='${type}') AS emerdata FROM dual`;
            // console.log(getdata);
             db.query(getdata,function(err,data)
                 {
                     if(err)
                     {
                         throw(err);
                     }
                     else 
                     {
                        var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,district)
                        {
 
                        if(err)
                        {
                         throw(err);
                        }
                        else{
                         var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                         db.query(query,function(err,pincode)
                         {
 
                         if(err)
                         {
                          throw(err);
                         }
                         else{
                             var usertype = req.session.user_type;
                             var permission = req.session.permision;
                             res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                        }
                      });
                     }
                         })
                    // 
                     }
         })
 
        }
        //end single parameter filter
        // double parameter filter
        else if((dist)!='' && (pincode)!='' && (age)=='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code ='${pincode}') AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)!='' && (pincode)=='' && (age)!='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })
        }
        else if((dist)!='' && (pincode)=='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS emerdata FROM dual`;
           console.log(getdata);
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        // end double parameter filter
        //triple parameter filter
        else if((dist)!='' && (pincode)!='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && crime_type='${type}' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && crime_type='${type}' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && crime_type='${type}' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && crime_type='${type}' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && crime_type='${type}' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && crime_type='${type}' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && crime_type='${type}' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && crime_type='${type}' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && crime_type='${type}' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && crime_type='${type}' && pin_code ='${pincode}') AS emerdata FROM dual`;            
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)!='' && (pincode)=='' && (age)!='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS emerdata FROM dual`;                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }
        else if((dist)!='' && (pincode)!='' && (age)!='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS emerdata FROM dual`;                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }
        //end triple parameter filter
        else if((dist)!='' && (pincode)!='' && (age)!='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS emerdata FROM dual`;                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }


        
        else
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                    {
                        if(err)
                        {
                            throw(err);
                        }
                        else 
                        {
                           var query = `SELECT DISTINCT dist FROM districtdata WHERE state='${area}'`;
                           db.query(query,function(err,district)
                           {
    
                           if(err)
                           {
                            throw(err);
                           }
                           else{
                            var query = `SELECT DISTINCT zipcode FROM districtdata WHERE state='${area}'`;
                            db.query(query,function(err,pincode)
                            {
    
                            if(err)
                            {
                             throw(err);
                            }
                            else{
    
                                // console.log({zila:district});
                                // console.log({pin:pincode});
                                var usertype = req.session.user_type;
                                var permission = req.session.permision;
                                res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                           }
                         });
                        }
                            })
                       
                        }
            })
        }
    }
    if ((usertype) == 2)
    {
        if((dist)!='' && (pincode)=='' && (age)=='' && (type)=='')
        {

        var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })
        }
        else if((dist)=='' && (pincode)!='' && (age)=='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code ='${pincode}') AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)=='' && (pincode)=='' && (age)!='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=crime.user_id  ) AS ddata ,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=crime.user_id ) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=crime.user_id ) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=crime.user_id ) AS isdata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=crime.user_id ) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=crime.user_id ) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=crime.user_id ) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=crime.user_id ) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=crime.user_id ) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=crime.user_id ) AS emerdata FROM dual`;
        //    console.log(getdata);
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })
        }
        else if((dist)=='' && (pincode)=='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence'  && crime_type='${type}' ) AS ddata ,(SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments'  && crime_type='${type}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing'  && crime_type='${type}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring'  && crime_type='${type}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures'  && crime_type='${type}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch'  && crime_type='${type}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment'  && crime_type='${type}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content'  && crime_type='${type}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road'  && crime_type='${type}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS'  && crime_type='${type}') AS emerdata FROM dual`;
            // console.log(getdata);
             db.query(getdata,function(err,data)
                 {
                     if(err)
                     {
                         throw(err);
                     }
                     else 
                     {
                        var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,district)
                        {
 
                        if(err)
                        {
                         throw(err);
                        }
                        else{
                         var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                         db.query(query,function(err,pincode)
                         {
 
                         if(err)
                         {
                          throw(err);
                         }
                         else{
                             var usertype = req.session.user_type;
                             var permission = req.session.permision;
                             res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                        }
                      });
                     }
                         })
                    // 
                     }
         })
 
        }
        //end single parameter filter
        // double parameter filter
        else if((dist)!='' && (pincode)!='' && (age)=='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code ='${pincode}') AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)!='' && (pincode)=='' && (age)!='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=crime.user_id &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })
        }
        else if((dist)!='' && (pincode)=='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && crime_type='${type}' &&  pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${dist}')) AS emerdata FROM dual`;
           console.log(getdata);
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        // end double parameter filter
        //triple parameter filter
        else if((dist)!='' && (pincode)!='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && crime_type='${type}' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && crime_type='${type}' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && crime_type='${type}' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && crime_type='${type}' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && crime_type='${type}' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && crime_type='${type}' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && crime_type='${type}' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && crime_type='${type}' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && crime_type='${type}' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && crime_type='${type}' && pin_code ='${pincode}') AS emerdata FROM dual`;            
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)!='' && (pincode)=='' && (age)!='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' ) AS emerdata FROM dual`;                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }
        else if((dist)!='' && (pincode)!='' && (age)!='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS emerdata FROM dual`;                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }
        //end triple parameter filter
        else if((dist)!='' && (pincode)!='' && (age)!='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS emerdata FROM dual`;                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }


        
        else
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                    {
                        if(err)
                        {
                            throw(err);
                        }
                        else 
                        {
                           var query = `SELECT DISTINCT dist FROM districtdata WHERE zone='${area}'`;
                           db.query(query,function(err,district)
                           {
    
                           if(err)
                           {
                            throw(err);
                           }
                           else{
                            var query = `SELECT DISTINCT zipcode FROM districtdata WHERE zone='${area}'`;
                            db.query(query,function(err,pincode)
                            {
    
                            if(err)
                            {
                             throw(err);
                            }
                            else{
    
                                // console.log({zila:district});
                                // console.log({pin:pincode});
                                var usertype = req.session.user_type;
                                var permission = req.session.permision;
                                res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                           }
                         });
                        }
                            })
                       
                        }
            })
        }
    }
    if ((usertype) == 3)
    {
       
         if((dist)=='' && (pincode)!='' && (age)=='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code ='${pincode}') AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)=='' && (pincode)=='' && (age)!='' && (type)=='')
        {
            // console.log(age);
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS ddata ,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS isdata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=crime.user_id && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS emerdata FROM dual`;
        //    console.log(getdata);
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                       db.query(query,function(err,district)
                       {

                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })
        }
        else if((dist)=='' && (pincode)=='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS ddata ,(SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS'  && crime_type='${type}' && pin_code IN (SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}')) AS emerdata FROM dual`
            // console.log(getdata);
             db.query(getdata,function(err,data)
                 {
                     if(err)
                     {
                         throw(err);
                     }
                     else 
                     {
                        var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                        db.query(query,function(err,district)
                        {
 
                        if(err)
                        {
                         throw(err);
                        }
                        else{
                         var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                         db.query(query,function(err,pincode)
                         {
 
                         if(err)
                         {
                          throw(err);
                         }
                         else{
                             var usertype = req.session.user_type;
                             var permission = req.session.permision;
                             res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                        }
                      });
                     }
                         })
                    // 
                     }
         })
 
        }
        //end single parameter filter

        //triple parameter filter
        else if((dist)=='' && (pincode)!='' && (age)=='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && crime_type='${type}' && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && crime_type='${type}' && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && crime_type='${type}' && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && crime_type='${type}' && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && crime_type='${type}' && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && crime_type='${type}' && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && crime_type='${type}' && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && crime_type='${type}' && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && crime_type='${type}' && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && crime_type='${type}' && pin_code ='${pincode}') AS emerdata FROM dual`;            
            db.query(getdata,function(err,data)
                {
                    if(err)
                    {
                        throw(err);
                    }
                    else 
                    {
                       var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                       db.query(query,function(err,district)
                       {
                       if(err)
                       {
                        throw(err);
                       }
                       else{
                        var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                        db.query(query,function(err,pincode)
                        {

                        if(err)
                        {
                         throw(err);
                        }
                        else{

                            // console.log({zila:district});
                            // console.log({pin:pincode});
                            var usertype = req.session.user_type;
                            var permission = req.session.permision;
                            res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                       }
                     });
                    }
                        })
                   
                    }
        })

        }
        else if((dist)=='' && (pincode)=='' && (age)!='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && crime_type='${type}' && pin_code IN(SELECT DISTINCT(zipcode) FROM districtdata WHERE dist='${area}') ) AS emerdata FROM dual`                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }
        else if((dist)=='' && (pincode)!='' && (age)!='' && (type)=='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}') AS emerdata FROM dual`;                 
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }
        //end triple parameter filter
        else if((dist)=='' && (pincode)!='' && (age)!='' && (type)!='')
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime,users WHERE incident_type='Domestic Violence' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS ddata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Comments' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS icdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Eve Teasing' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS etdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Staring' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS isdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Gestures' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS igdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Indecent Touch' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS itdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Sexual Harrasment' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS shdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Online Vulgar Content' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS ovcdata, (SELECT COUNT(*) FROM Crime,users WHERE incident_type='Chasing On Road' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS cordata,(SELECT COUNT(*) FROM Crime,users WHERE incident_type='Emergency SOS' && users.age='${age}' && users.id=Crime.user_id && pin_code ='${pincode}' && Crime.crime_type='${type}') AS emerdata FROM dual`;                 
            //  console.log(getdata);
            db.query(getdata,function(err,data)
            {
                if(err)
                {
                    throw(err);
                }
                else 
                {
                   var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                   db.query(query,function(err,district)
                   {
                   if(err)
                   {
                    throw(err);
                   }
                   else{
                    var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                    db.query(query,function(err,pincode)
                    {

                    if(err)
                    {
                     throw(err);
                    }
                    else{

                        // console.log({zila:district});
                        // console.log({pin:pincode});
                        var usertype = req.session.user_type;
                        var permission = req.session.permision;
                        res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                   }
                 });
                }
                    })
               
                }
             })

        }


        
        else
        {
            var getdata = `SELECT( SELECT COUNT(*) FROM Crime WHERE incident_type='Domestic Violence' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS ddata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Comments' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS icdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Eve Teasing' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS etdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Staring' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS isdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Gestures' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS igdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Indecent Touch' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS itdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Sexual Harrasment' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS shdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Online Vulgar Content' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS ovcdata, (SELECT COUNT(*) FROM Crime WHERE incident_type='Chasing On Road' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS cordata,(SELECT COUNT(*) FROM Crime WHERE incident_type='Emergency SOS' && pin_code IN (SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}' )) AS emerdata FROM dual`;
            db.query(getdata,function(err,data)
                    {
                        if(err)
                        {
                            throw(err);
                        }
                        else 
                        {
                           var query = `SELECT DISTINCT dist FROM districtdata WHERE dist='${area}'`;
                           db.query(query,function(err,district)
                           {
    
                           if(err)
                           {
                            throw(err);
                           }
                           else{
                            var query = `SELECT DISTINCT zipcode FROM districtdata WHERE dist='${area}'`;
                            db.query(query,function(err,pincode)
                            {
    
                            if(err)
                            {
                             throw(err);
                            }
                            else{
    
                                // console.log({zila:district});
                                // console.log({pin:pincode});
                                var usertype = req.session.user_type;
                                var permission = req.session.permision;
                                res.render("analytics.ejs",{permission, alldata: data,zila:district,pin:pincode, usertype });
                           }
                         });
                        }
                            })
                       
                        }
            })
        }

        
    }
   } 
    else{
       res.redirect("/");
    }
   
   
   
})
app.get("/womensLaws",function(req,res,next){
    if (req.session.username) {
        var querys = "SELECT * FROM term_condition";
        db.query(querys, function (err, data) {
            if (err) {
                throw (err)
            }
            else {
               
                var permission = req.session.permision;
                var username = req.session.username;
                res.render("womens_law.ejs", { permission, policy: data ,username});
            }
        })

    }
    else
    {
        res.redirect("/");
    }
})
app.post('/lawupdate', function (req, res, next) {
    if (req.session.username) {
        var terms = req.body.terms;
        // console.log(`UPDATE term_condition SET term_condition = '${terms}' WHERE id = '1'`);
        var updateterms = `UPDATE term_condition SET womens_law = '${terms}' WHERE id = '1'`;
        db.query(updateterms, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                req.flash('success','Women Laws Update Successfully');
                res.redirect("/womensLaws");
            }
        })
    }
    else {
        res.redirect("/");
    }
})
app.get("/government_scheme",function(req,res,next){
    if (req.session.username) {
        var querys = "SELECT * FROM term_condition";
        db.query(querys, function (err, data) {
            if (err) {
                throw (err)
            }
            else {
                // console.log({policy:data})
                var permission = req.session.permision;
                var username = req.session.username;
              
                res.render("governament_scheme.ejs", { permission, policy: data,username });
            }
        })

    }
    else
    {
        res.redirect("/");
    }
})
app.post('/schemeupdate', function (req, res, next) {
    if (req.session.username) {
        var terms = req.body.terms;
        // console.log(`UPDATE term_condition SET term_condition = '${terms}' WHERE id = '1'`);
        var updateterms = `UPDATE term_condition SET government_scheme = '${terms}' WHERE id = '1'`;
        db.query(updateterms, function (err, data) {
            if (err) {
                throw (err);
            }
            else {
                req.flash('success','Government Scheme Update Successfully')
                res.redirect("/government_scheme");
            }
        })
    }
    else {
        res.redirect("/");
    }
})
app.get("/hotspot",function(req,res,next){
    if (req.session.username) {
        var permission = req.session.permision;
        var username = req.session.username;
        res.render("hotspost.ejs",{permission,username});
    }
    else{
        res.redirect("/");
    }
})
app.listen(3030, () => {
    console.log("This port number 3030 is running");
});